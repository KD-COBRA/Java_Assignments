package Online_Exam;

public interface Exam {
    void startExam();
    void submitExam();
    float getExamResult();
}