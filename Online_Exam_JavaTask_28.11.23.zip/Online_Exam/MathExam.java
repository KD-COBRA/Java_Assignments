package Online_Exam;

public class MathExam implements Exam {
    private boolean isStarted;
    private boolean isSubmitted;
    private float mathResult;

    public void startExam() {
        if (!isStarted) {
            System.out.println("Math exam started.");
            isStarted = true;
        } else {
            System.out.println("Math exam has already started.");
        }
    }

    public void submitExam() {
        if (isStarted && !isSubmitted) {
            mathResult = calculateMathResult();
            System.out.println("Math exam submitted.");
            isSubmitted = true;
        } else if (!isStarted) {
            System.out.println("Math exam cannot be submitted before starting.");
        } else {
            System.out.println("Math exam has already been submitted.");
        }
    }

    public float getExamResult() {
        if (isSubmitted) {
            System.out.println("Math exam result: " + mathResult);
            return mathResult;
        } else {
            System.out.println("Math exam result is not available as the exam has not been submitted.");
            return -1;
        }
    }

    private float calculateMathResult() {

        return 90.5f;
    }
}
