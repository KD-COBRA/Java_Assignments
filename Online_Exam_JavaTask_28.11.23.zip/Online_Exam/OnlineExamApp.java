package Online_Exam;


public class OnlineExamApp {
    public static void main(String[] args) {
        Exam mathExam = new MathExam();
        mathExam.startExam();
        mathExam.submitExam();
        mathExam.getExamResult();

        Exam scienceExam = new ScienceExam();
        scienceExam.startExam();
        scienceExam.submitExam();
        scienceExam.getExamResult();
    }
}
