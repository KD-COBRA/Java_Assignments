package Online_Exam;

public class ScienceExam implements Exam {
    private boolean isStarted;
    private boolean isSubmitted;
    private float scienceResult;

    public void startExam() {
        if (!isStarted) {
            System.out.println("Science exam started.");
            isStarted = true;
        } else {
            System.out.println("Science exam has already started.");
        }
    }

    public void submitExam() {
        if (isStarted && !isSubmitted) {
            scienceResult = calculateScienceResult();
            System.out.println("Science exam submitted.");
            isSubmitted = true;
        } else if (!isStarted) {
            System.out.println("Science exam cannot be submitted before starting.");
        } else {
            System.out.println("Science exam has already been submitted.");
        }
    }

    public float getExamResult() {
        if (isSubmitted) {
            System.out.println("Science exam result: " + scienceResult);
            return scienceResult;
        } else {
            System.out.println("Science exam result is not available as the exam has not been submitted.");
            return -1;
        }
    }

    private float calculateScienceResult() {

        return 85.0f;
    }
}
